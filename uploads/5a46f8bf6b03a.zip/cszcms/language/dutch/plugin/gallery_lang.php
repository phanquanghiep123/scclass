<?php
//Article Index
$lang['gallery_header']			= "Galerij";
$lang['gallery_album']                  = "Album/Omschrijving";
$lang['gallery_datetime']               = "Datum/Tijd";
$lang['gallery_widget_remark']		= "{language_iso} is de taal code voor de front-end. Terug te vinden in 'taal' sectie in het achterliggend systeem";

//Article new/edit
$lang['gallery_remark']                 = "Upload de afbeelding, pas het album aan.";
$lang['gallery_new_header']		= "Nieuw Album";
$lang['gallery_albumname']              = "Album Naam";
$lang['gallery_keyword']                = "Kernwoord";
$lang['gallery_short_desc']             = "Korte Omschrijving";
$lang['gallery_picture']                = "Upload Afbeeldingen";
$lang['gallery_fileallow']              = "Enkel (jpg, jpeg, png, gif) zijn toegelaten. Afbeelding is niet groter dan 1900px in hoogte of breedte.";
$lang['gallery_caption']                = "Onderschrift";
$lang['gallery_list_remark']            = "Is album omslagfoto";
$lang['gallery_youtube_head']            = "Voege Nieuwe Youtube Toe";
$lang['gallery_youtube_url']            = "Youtube URL";