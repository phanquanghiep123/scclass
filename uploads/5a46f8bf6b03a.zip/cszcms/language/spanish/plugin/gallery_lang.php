<?php
//Article Index
$lang['gallery_header']			= "Galeria";
$lang['gallery_album']                  = "Album/Descripción";
$lang['gallery_datetime']               = "Fecha/Hora";
$lang['gallery_widget_remark']		= "{language_iso} es el lenguaje codigo para la vista de usuario.";

//Article new/edit
$lang['gallery_remark']                 = "Subir la imagen. Editar este album.";
$lang['gallery_new_header']		= "Nuevo Album";
$lang['gallery_albumname']              = "Nombre del Album";
$lang['gallery_keyword']                = "Palabras clave";
$lang['gallery_short_desc']             = "Descripción Corta";
$lang['gallery_picture']                = "Imagenes Subidas";
$lang['gallery_fileallow']              = "Solo archivos (jpg, jpeg, png, gif). El peso de la imagen no puede ser mayor a 1900px en ancho o alto.";
$lang['gallery_caption']                = "Subtítulo";
$lang['gallery_list_remark']            = "Es la cubierta de la imagen del álbum";
$lang['gallery_youtube_head']            = "Agregar nuevo video Youtube";
$lang['gallery_youtube_url']            = "Youtube URL";
