<?php
//Article Index
$lang['gallery_header']			= "แกลเลอรี";
$lang['gallery_album']                  = "อัลบั้ม/รายละเอียด";
$lang['gallery_datetime']               = "วัน/เวลา";
$lang['gallery_widget_remark']		= "{language_iso} เป็นต่อย่อภาษาสำหรับหน้าเว็บ. คุณสามารถดูได้ในส่วนของ 'ภาษา' บนระบบเบื้องหลัง";

//Article new/edit
$lang['gallery_remark']                 = "อัปโหลดภาพ โปรดแก้ไขอัลบั้มนี้";
$lang['gallery_new_header']		= "อัลบั้มใหม่";
$lang['gallery_albumname']              = "ชื่ออัลบั้ม";
$lang['gallery_keyword']                = "คีย์เวิร์ด";
$lang['gallery_short_desc']             = "รายละเอียดแบบย่อ";
$lang['gallery_picture']                = "อัพโหลดรูปภาพ";
$lang['gallery_fileallow']              = "สำหรับไฟล์ (jpg, jpeg, png, gif) เท่านั้นจะได้รับอนุญาต. ขนาดของภาพไม่เกิน 1900px กับความกว้างหรือความสูง.";
$lang['gallery_caption']                = "คำอธิบายภาพ";
$lang['gallery_list_remark']            = "เป็นภาพปกอัลบั้ม";
$lang['gallery_youtube_head']            = "เพิ่ม Youtube ใหม่";
$lang['gallery_youtube_url']            = "Youtube URL";