<?php
//Article Index
$lang['gallery_header']			= "Gallery";
$lang['gallery_album']                  = "Album/Description";
$lang['gallery_datetime']               = "Date/Time";
$lang['gallery_widget_remark']		= "{language_iso} is the language code for frontend. You can see in 'Language' section on backend system.";

//Article new/edit
$lang['gallery_remark']                 = "Upload the picture. Please edit this album.";
$lang['gallery_new_header']		= "New Album";
$lang['gallery_albumname']              = "Album Name";
$lang['gallery_keyword']                = "Keyword";
$lang['gallery_short_desc']             = "Short Description";
$lang['gallery_picture']                = "Pictures Upload";
$lang['gallery_fileallow']              = "Only files (jpg, jpeg, png, gif) are allowed. Image size is not over 1900px on width or height.";
$lang['gallery_caption']                = "Caption";
$lang['gallery_list_remark']            = "is album image cover";
$lang['gallery_youtube_head']            = "Add New Youtube";
$lang['gallery_youtube_url']            = "Youtube URL";