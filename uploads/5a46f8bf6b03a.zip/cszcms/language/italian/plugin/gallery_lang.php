<?php
//Article Index
$lang['gallery_header']			= "Galleria";
$lang['gallery_album']                  = "Album/Descrizione";
$lang['gallery_datetime']               = "Data/Ora";
$lang['gallery_widget_remark']		= "{language_iso} è la lingua del tuo frontend. Visualizza nel backend .";

//Article new/edit
$lang['gallery_remark']                 = "Upload immagine. Modifica questo album.";
$lang['gallery_new_header']		= "Nuovo Album";
$lang['gallery_albumname']              = "Nome Album ";
$lang['gallery_keyword']                = "Keyword";
$lang['gallery_short_desc']             = "Descrizione breve";
$lang['gallery_picture']                = "Carica immagini";
$lang['gallery_fileallow']              = "Solo files (jpg, jpeg, png, gif) permessi. Dimensioni superiori a 1900px non permesse.";
$lang['gallery_caption']                = "Didascalia";
$lang['gallery_list_remark']            = "è la cover dell'immagine";
$lang['gallery_youtube_head']            = "Aggiungi nuovo video Youtube";
$lang['gallery_youtube_url']            = "Youtube URL";