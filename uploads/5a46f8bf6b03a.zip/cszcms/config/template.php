<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/* For Default Template */
$config['template_master']  = 'main'; /* File in View/Templates */
$config['template_name']  = 'cszdefault'; /* Template default name */
$config['template_folder']  = 'templates';
$config['data_container']   = 'content';