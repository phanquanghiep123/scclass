<?php  
defined('BASEPATH') OR exit('No direct script access allowed');

/* Session namespace */
$config['sess_namespace'] = 'cszcms_'.md5(EMAIL_DOMAIN);
/* End of file session.php */
/* Location: ./application/config/session.php */