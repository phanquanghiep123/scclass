$('.carousel').carousel({interval:5000});
function ChkHideShow(id) {
    $('#' + id).toggle(200);
}