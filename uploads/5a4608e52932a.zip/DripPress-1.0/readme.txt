=== DripPress ===
Contributors: norcross
Tags: content dripping, restricted content
Donate link: http://andrewnorcross.com/donate
Requires at least: 3.7
Tested up to: 3.9.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Control content visibility based on user signup date

== Description ==

DripPress will restrict content viewability based on an individual user's signup date. The post editor will add a new metabox to set the the duration. All available data points and calculations are filterable to adapt to various membership plugins.


== Installation ==

1. Upload the `drippress` folder to the `/wp-content/plugins/` directory or install from the dashboard
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Add durations to content

== Frequently Asked Questions ==

= Why? =

Why not?


== Screenshots ==

1. A thing


== Changelog ==

= 1.0.0 =
* Initial release


== Upgrade Notice ==

= 1.0.0 =
Initial release


